# Working-Coin-Clicker-2.0
Instructions/Guide: 
- Click the "COIN" to get money.
- Click the "SPEAKER" to mute and unmute the music.
- Click "SHOP" to open the shop.
- Click "CLOSE" to close the shop.
- PRESS S TO SAVE AND L TO LOAD & C TO CLOSE
