# Working-Coin-Clicker-2.0
GUIDE: 
- Click the "COIN" to get money and stuff.
- Click the "SPEAKER" to mute and unmute and stuff.
